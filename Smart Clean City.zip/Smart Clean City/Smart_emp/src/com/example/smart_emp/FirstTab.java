package com.example.smart_emp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class FirstTab extends Fragment {
	
	LocationManager location_manager;

	double x;
	double y;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.req, container, false);

		ImageButton b1 = (ImageButton) rootView.findViewById(R.id.ImageButton01);
		ImageButton b2 = (ImageButton) rootView.findViewById(R.id.ImageButton02);
		
		location_manager = (LocationManager) getActivity().getSystemService(
				Context.LOCATION_SERVICE);

		b1.setOnClickListener(new View.OnClickListener() {

			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(
						FirstTab.this.getActivity());

				myAlertDialog.setTitle("Conform send the request?");
				myAlertDialog.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface arg0, int arg1) {
								// do something when the OK button is clicked

								
								LocationListener listner = new MLocationListner();
								location_manager
										.requestLocationUpdates(
												android.location.LocationManager.GPS_PROVIDER,
												0, 0, listner);
								

							}
						});

				myAlertDialog.setNegativeButton("Cancel",
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface arg0, int arg1) {
								// do something when the Cancel button is
								// clicked
							}
						});

				myAlertDialog.show();

			}

		});

		b2.setOnClickListener(new View.OnClickListener() {

			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(
						FirstTab.this.getActivity());

				myAlertDialog.setTitle("Conform send the request?");

				myAlertDialog.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface arg0, int arg1) {
								// do something when the OK button is clicked
								
								LocationListener listner = new MLocationListner1();
								location_manager
										.requestLocationUpdates(
												android.location.LocationManager.GPS_PROVIDER,
												0, 0, listner);
								
								
							}
						});
				
				myAlertDialog.setNegativeButton("Cancel",
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface arg0, int arg1) {
								// do something when the Cancel button is clicked
								
							}
						});
				
				myAlertDialog.show();

			}
		});

		/*
		 * Intent intent = new Intent(getActivity(),MainActivity.class);
		 * startActivity(intent);
		 */

		return rootView;

	}
	
	
	public class MLocationListner implements LocationListener {

		@SuppressWarnings("static-access")
		@TargetApi(Build.VERSION_CODES.GINGERBREAD)
		public void onLocationChanged(Location location) {
			// TODO Auto-generated method stub

			x = location.getLatitude();
			y = location.getLongitude();

			try {
				Geocoder geocoder = new Geocoder(FirstTab.this.getActivity(),
						Locale.ENGLISH);
				List<Address> addresses = geocoder.getFromLocation(x, y, 1);

				if (geocoder.isPresent()) {

					Address returnAddress = addresses.get(0);
					location_manager.removeUpdates(this);	
					String l1 = Double.toString(x);
					String l2 = Double.toString(y);
					String l3 = returnAddress.getSubLocality();
					String l4 = returnAddress.getLocality();

						l1 = URLEncoder.encode(l1, "UTF-8");
						l2 = URLEncoder.encode(l2, "UTF-8");
						l3 = URLEncoder.encode(l3, "UTF-8");
						l4 = URLEncoder.encode(l4, "UTF-8");

						String url1 = Config.ur + "emp_publicbin.php?la=" + l1.trim() + "&lo="
								+ l2.trim() + "&ar=" + l3.trim() + "&ci="
								+ l4.trim();

						pass_value_to_db get1 = new pass_value_to_db();
						get1.execute(new String[] { url1 });

						String va1 = get1.get();

						Toast.makeText(getApplicationContext(), va1,
								Toast.LENGTH_LONG).show();
					}
						
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block

				Log.e("tag", e.getMessage());
			}

		}

		private Context getApplicationContext() {
			// TODO Auto-generated method stub
			return getActivity();
		}

		public void onProviderDisabled(String arg0) {
			// TODO Auto-generated method stub

		}

		public void onProviderEnabled(String arg0) {
			// TODO Auto-generated method stub

		}

		public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
			// TODO Auto-generated method stub

		}

	}

	public class MLocationListner1 implements LocationListener {

		@SuppressWarnings("static-access")
		@TargetApi(Build.VERSION_CODES.GINGERBREAD)
		public void onLocationChanged(Location location) {
			// TODO Auto-generated method stub

			x = location.getLatitude();
			y = location.getLongitude();

			try {
				Geocoder geocoder = new Geocoder(FirstTab.this.getActivity(),
						Locale.ENGLISH);
				List<Address> addresses = geocoder.getFromLocation(x, y, 1);

				if (geocoder.isPresent()) {

					Address returnAddress = addresses.get(0);
					location_manager.removeUpdates(this);	
					String l1 = Double.toString(x);
					String l2 = Double.toString(y);
					String l3 = returnAddress.getSubLocality();
					String l4 = returnAddress.getLocality();
					String l5 = returnAddress.getAdminArea();
					
						l1 = URLEncoder.encode(l1, "UTF-8");
						l2 = URLEncoder.encode(l2, "UTF-8");
						l3 = URLEncoder.encode(l3, "UTF-8");
						l4 = URLEncoder.encode(l4, "UTF-8");

						String url1 = Config.ur + "emp_canpublicbin.php?la=" + l1.trim() + "&lo="
								+ l2.trim() + "&ar=" + l3.trim() + "&ci="
								+ l4.trim();

						pass_value_to_db get1 = new pass_value_to_db();
						get1.execute(new String[] { url1 });

						String va1 = get1.get();

						Toast.makeText(getApplicationContext(), va1,
								Toast.LENGTH_LONG).show();
					}
						
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block

				Log.e("tag", e.getMessage());
			}

		}

		private Context getApplicationContext() {
			// TODO Auto-generated method stub
			return getActivity();
		}

		public void onProviderDisabled(String arg0) {
			// TODO Auto-generated method stub

		}

		public void onProviderEnabled(String arg0) {
			// TODO Auto-generated method stub

		}

		public void onStatusChanged(String arg0, int arg1, Bundle arg2) {
			// TODO Auto-generated method stub

		}

	}


	class pass_value_to_db extends AsyncTask<String, Void, String> {

		ProgressDialog dialog;

		@Override
		protected void onPreExecute() { // TODO Auto-generated method stub
			dialog = new ProgressDialog(FirstTab.this.getActivity());
			dialog.setTitle("Processing...");
			dialog.setMessage("Please wait...");
			dialog.setCancelable(false);
			dialog.show();
		}

		@Override
		protected String doInBackground(String... urls) {
			String result = "";
			for (String url : urls) {
				InputStream is = null;
				try {

					HttpClient httpclient = new DefaultHttpClient();
					HttpPost httppost = new HttpPost(url);
					HttpResponse response = httpclient.execute(httppost);
					int status = response.getStatusLine().getStatusCode();
					Log.d("KG", "status=" + status);

					if (status == 200) {
						HttpEntity entity = response.getEntity();
						is = entity.getContent();
						BufferedReader reader = new BufferedReader(
								new InputStreamReader(is, "iso-8859-1"), 8);
						String line = "";
						while ((line = reader.readLine()) != null) {
							result += line;
						}
						is.close();

						Log.v("KG", result);

					}
				} catch (Exception ex) {
					Log.e("Error", ex.toString());
				}
			}
			return result;
		}

		protected void onPostExecute(String result) {
			Log.v("KG", "output=" + result);
			result = result.trim();

			if (result.equals("false")) {

				Toast.makeText(getApplicationContext(),
						" Please try again later...", Toast.LENGTH_LONG).show();
			} else {
				System.out.println(result);

			}

			if (dialog != null)
				dialog.dismiss();

		}

		private Context getApplicationContext() {
			// TODO Auto-generated method stub
			return getActivity();
		}

	}
}
