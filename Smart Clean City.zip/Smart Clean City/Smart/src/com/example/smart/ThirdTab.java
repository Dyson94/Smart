package com.example.smart;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.concurrent.ExecutionException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ThirdTab extends Fragment {
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.feedback, container, false);

		final SharedPreferences sharedpreferences = getActivity()
				.getSharedPreferences("smart", Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedpreferences.edit();
		final String a = sharedpreferences.getString("ph", null);
		editor.commit();

		final EditText ed = (EditText) rootView.findViewById(R.id.editText1);
		Button bn = (Button) rootView.findViewById(R.id.button1);

		final EditText ed1 = (EditText) rootView.findViewById(R.id.editText2);
		Button bn1 = (Button) rootView.findViewById(R.id.button2);

		Button bn2 = (Button) rootView.findViewById(R.id.button3);
		
		bn.setOnClickListener(new View.OnClickListener() {

			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(
						ThirdTab.this.getActivity());
				myAlertDialog.setTitle("Conform send the Feedback?");

				myAlertDialog.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface arg0, int arg1) {
								// do something when the OK button is clicked

								String url = Config.ur + "user_detail.php?ph="
										+ a;

								pass_value_to_db get = new pass_value_to_db();
								get.execute(new String[] { url });

								try {

									String val = get.get();
									String va[] = val.split("/");

									String a = va[1];
									String b = va[6];

									if (va != null) {
										String na = a.toString();
										String ph = b.toString();
										String ty = "feedback";
										String de = ed.getText().toString();

										na = URLEncoder.encode(na, "UTF-8");
										ph = URLEncoder.encode(ph, "UTF-8");
										ty = URLEncoder.encode(ty, "UTF-8");
										de = URLEncoder.encode(de, "UTF-8");

										String url1 = Config.ur
												+ "user_feed.php?na="
												+ na.trim() + "&ph="
												+ ph.trim() + "&ty="
												+ ty.trim() + "&de="
												+ de.trim();

										pass_value_to_db get1 = new pass_value_to_db();
										get1.execute(new String[] { url1 });

										String va1 = get1.get();
										String re = "Sending Successfully";

										
										if (va1.equalsIgnoreCase(re)) {

											Toast.makeText(getApplicationContext(),
													"Sending Successfully",
													Toast.LENGTH_LONG).show();

											ed.setText("");
											ed1.setText(""); 
										}
										
										else{
											
											Toast.makeText(getApplicationContext(),
													va1,
													Toast.LENGTH_LONG).show();
										}
									}

								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (ExecutionException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (UnsupportedEncodingException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

							}

							private Context getApplicationContext() {
								// TODO Auto-generated method stub
								return getActivity();
							}
						});

				myAlertDialog.setNegativeButton("Cancel",
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface arg0, int arg1) {
								// do something when the Cancel button is
								// clicked

							}
						});

				myAlertDialog.show();

			}
		});

		bn1.setOnClickListener(new View.OnClickListener() {

			public void onClick(View arg0) {
				// TODO Auto-generated method stub

				AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(
						ThirdTab.this.getActivity());
				myAlertDialog.setTitle("Conform send the Complaint?");

				myAlertDialog.setPositiveButton("OK",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface arg0, int arg1) {
								// do something when the OK button is clicked

								String url = Config.ur + "user_detail.php?ph="
										+ a;

								pass_value_to_db get = new pass_value_to_db();
								get.execute(new String[] { url });

								try {

									String val = get.get();
									String va[] = val.split("/");

									String a = va[1];
									String b = va[6];

									if (va != null) {
										String na = a.toString();
										String ph = b.toString();
										String ty = "complaint";
										String de = ed1.getText().toString();

										na = URLEncoder.encode(na, "UTF-8");
										ph = URLEncoder.encode(ph, "UTF-8");
										ty = URLEncoder.encode(ty, "UTF-8");
										de = URLEncoder.encode(de, "UTF-8");

										String url1 = Config.ur
												+ "user_feed.php?na="
												+ na.trim() + "&ph="
												+ ph.trim() + "&ty="
												+ ty.trim() + "&de="
												+ de.trim();

										pass_value_to_db get1 = new pass_value_to_db();
										get1.execute(new String[] { url1 });

										String va1 = get1.get();
										String re = "Sending Successfully";

										
										if (va1.equalsIgnoreCase(re)) {

											Toast.makeText(getApplicationContext(),
													"Sending Successfully",
													Toast.LENGTH_LONG).show();

											ed.setText("");
											ed1.setText(""); 
										}
										
										else{
											
											Toast.makeText(getApplicationContext(),
													va1,
													Toast.LENGTH_LONG).show();
										}
									}

								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (ExecutionException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (UnsupportedEncodingException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

							}

							private Intent getIntent() {
								// TODO Auto-generated method stub
								return null;
							}

							private void startActivity(FragmentActivity activity) {
								// TODO Auto-generated method stub

							}

							private void finish() {
								// TODO Auto-generated method stub

							}

							private Context getApplicationContext() {
								// TODO Auto-generated method stub
								return getActivity();
							}
						});

				myAlertDialog.setNegativeButton("Cancel",
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface arg0, int arg1) {
								// do something when the Cancel button is
								// clicked

							}
						});

				myAlertDialog.show();

			}
		});

		bn2.setOnClickListener(new View.OnClickListener() {

			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				ed.setText("");
				ed1.setText(""); 
				
			}
		});

		return rootView;
	}

	class pass_value_to_db extends AsyncTask<String, Void, String> {

		ProgressDialog dialog;

		@Override
		protected void onPreExecute() { // TODO Auto-generated method stub
			dialog = new ProgressDialog(ThirdTab.this.getActivity());
			dialog.setTitle("Processing...");
			dialog.setMessage("Please wait...");
			dialog.setCancelable(false);
			dialog.show();
		}

		@Override
		protected String doInBackground(String... urls) {
			String result = "";
			for (String url : urls) {
				InputStream is = null;
				try {

					HttpClient httpclient = new DefaultHttpClient();
					HttpPost httppost = new HttpPost(url);
					HttpResponse response = httpclient.execute(httppost);
					int status = response.getStatusLine().getStatusCode();
					Log.d("KG", "status=" + status);

					if (status == 200) {
						HttpEntity entity = response.getEntity();
						is = entity.getContent();
						BufferedReader reader = new BufferedReader(
								new InputStreamReader(is, "iso-8859-1"), 8);
						String line = "";
						while ((line = reader.readLine()) != null) {
							result += line;
						}
						is.close();

						Log.v("KG", result);

					}
				} catch (Exception ex) {
					Log.e("Error", ex.toString());
				}
			}
			return result;
		}

		protected void onPostExecute(String result) {
			Log.v("KG", "output=" + result);
			result = result.trim();

			if (result.equals("false")) {

				Toast.makeText(getApplicationContext(),
						" Please try again later...", Toast.LENGTH_LONG).show();
			} else {
				System.out.println(result);

			}

			if (dialog != null)
				dialog.dismiss();

		}

		private Context getApplicationContext() {
			// TODO Auto-generated method stub
			return getActivity();
		}

	}

}
