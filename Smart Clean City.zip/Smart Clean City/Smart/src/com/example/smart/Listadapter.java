package com.example.smart;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class Listadapter extends ArrayAdapter<String> {

	private final Activity context;
	private final String[] arr;
	private final Integer imageId;
	
	public Listadapter(Activity context, String[] arr,Integer imageId) {
		super(context, R.layout.list, arr);
		this.context = context;
		this.arr = arr;
		this.imageId = imageId;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		LayoutInflater inflater=context.getLayoutInflater();
		View rowView=inflater.inflate(R.layout.list,null,true);
		
		TextView txtname=(TextView)rowView.findViewById(R.id.textView1);
		TextView txtdesc=(TextView)rowView.findViewById(R.id.textView2);
		TextView txtde=(TextView)rowView.findViewById(R.id.textView3);
		ImageView imageView = (ImageView) rowView.findViewById(R.id.imageView1);
		
		String data[]=arr[position].split(",");
		txtname.setText("  "+data[0]);
		txtdesc.setText("    "+data[2]);
		txtde.setText("   "+data[1]);
		imageView.setImageResource(imageId);
		
		return rowView;
	}
	


}
