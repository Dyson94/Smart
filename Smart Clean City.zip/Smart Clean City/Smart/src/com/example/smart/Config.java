package com.example.smart;

public class Config {

	public static final String ur="http://192.168.43.63/Smart/";
}
