<?php

require("conn.php");

$ph=$_GET["ph"];
$date = date("y/m/d");

$check_uname="select * from tbl_addbin where ph='$ph'";
$run=mysql_query($check_uname);
if(mysql_num_rows($run)>0)
{
echo "Already You send the request for today";
}
else
{
$exe=mysql_query("insert into tbl_addbin values(null,'$ph','$date','0')") or die(mysql_error());

if($exe)
{
   echo "Request send Successfully";
}
else
{
  echo "Request Failed to send Please Try Again";	
}
}
?>
