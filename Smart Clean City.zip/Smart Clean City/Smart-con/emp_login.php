<?php

require("conn.php");

$na = $_GET["id"];
$id = $_GET["pa"];

$check_uname="select name,empid from tbl_employee where empid='$na' and pass='$id'";
$run=mysql_query($check_uname);
if(mysql_num_rows($run)>0)
{
	echo "su";
}
else
{
	echo "no";	
}

?>
