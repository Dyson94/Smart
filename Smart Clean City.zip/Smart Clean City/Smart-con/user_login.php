<?php

require("conn.php");

function getRandomWord($len = 6) {
    $word = array_merge(range('0', '9'));
    shuffle($word);
    return substr(implode($word), 0, $len);
}

$ranStr = getRandomWord();

$ph = $_GET["ph"];

$check_uname="select * from tbl_register where ph='$ph'";
$run=mysql_query($check_uname);
if(mysql_num_rows($run)>0)
{
$exe=mysql_query("update tbl_register set otp='$ranStr' where ph='$ph'") or die(mysql_error());

if($exe)
{
	echo "su";
}
else
{
	echo "no";	
}
}
else
{				 
	echo "no";
}
?>
