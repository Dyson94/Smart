<?php

require("conn.php");
$ph=$_GET["ph"];

$exe=mysql_query("select * from tbl_register where ph='$ph'") or die(mysql_error());

while($re=mysql_fetch_array($exe))
{
	echo $re['id']."/".$re['name']."/".$re['dno']."/".$re['str']."/".$re['area']."/".$re['city']."/".$re['ph']."/";
}
?>