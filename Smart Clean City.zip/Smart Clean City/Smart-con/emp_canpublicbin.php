<?php

require("conn.php");

$la=$_GET["la"];
$lo=$_GET["lo"];
$ar=$_GET["ar"];
$ci=$_GET["ci"];

$check_uname="select * from tbl_publicbin where lat='$la' and lon='$lo' and area='$ar' and city='$ci'";
$run=mysql_query($check_uname);
if(mysql_num_rows($run)>0)
{
	$ru=mysql_query("DELETE FROM `tbl_publicbin` WHERE `lat`='$la' AND `lon`='$la' AND `area`='$ar' AND `city`='$ci'");
}
else
{
  echo "Your request Failed Please Try Again";	
}

?>