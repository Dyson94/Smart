<?php

require("conn.php");

$exe=mysql_query("select * from tbl_schedule") or die(mysql_error());

while($re=mysql_fetch_array($exe))
{
	echo $re['area'];
}
?>