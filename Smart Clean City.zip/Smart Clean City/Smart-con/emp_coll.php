<?php
require("conn.php");

$ph=$_GET["ph"];

$exe=mysql_query("update tbl_officialbin set status='1' where ph='$ph'") or die(mysql_error());

if($exe)
{
   echo "Done!";
}
else
{
  echo "Your request Failed Please Try Again";	
}

?>