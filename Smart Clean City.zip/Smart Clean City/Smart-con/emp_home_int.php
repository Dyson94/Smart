<?php

require("conn.php");

$a = $_GET['ph'];

$exe=mysql_query("select * from tbl_officialbin where ph='$a'") or die(mysql_error());

while($re=mysql_fetch_array($exe))
{
	
$ph = $re['ph'];	

$exe1=mysql_query("select * from tbl_register where ph='$ph'") or die(mysql_error());
while($re1=mysql_fetch_array($exe1))
{

	echo $re1['name']."/".$re1['dno']."/".$re1['str']."/".$re1['area']."/".$re1['city']."/".$re1['ph']."/";
}
}

?>