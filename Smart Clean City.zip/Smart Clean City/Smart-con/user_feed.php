<?php

require("conn.php");

$us=$_GET["na"];
$ph=$_GET["ph"];
$ty=$_GET["ty"];
$de=$_GET["de"];
$date = date("y/m/d");

$check_uname="select * from `tbl_feed&com` where ph='$ph' and type='$ty' and date='$date' ";
$run=mysql_query($check_uname);
if(mysql_num_rows($run)>0)
{
echo "Already You send the request for today";
}
else
{
$exe=mysql_query("INSERT INTO `tbl_feed&com`( `name`, `ph`, `type`, `des`, `date`) VALUES ('$us','$ph','$ty','$de','$date')") or die(mysql_error());

if($exe)
{
   echo "Sending Successfully";
}
else
{
  echo "Sending Failed";	
}
}
?>
