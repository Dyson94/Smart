<?php

require("conn.php");

$la=$_GET["la"];
$lo=$_GET["lo"];
$str=$_GET["str"];
$ar=$_GET["ar"];
$ci=$_GET["ci"];

$check_uname="select * from tbl_publicbin where lat='$la' and lon='$lo' and area='$ar' and city='$ci'";
$run=mysql_query($check_uname);
if(mysql_num_rows($run)>0)
{
echo "Already You send the request for today";
}
else
{
$exe=mysql_query("insert into tbl_publicbin values(null,'$la','$lo','$str','$ar','$ci','','','')") or die(mysql_error());

if($exe)
{
   echo "Bin set to the place";
}
else
{
  echo "Your request Failed Please Try Again";	
}
}
?>