<?php
require("conn.php");

$us=$_GET["na"];
$dr=$_GET["dr"];
$st=$_GET["st"];
$ar=$_GET["ar"];
$ci=$_GET["ci"];
$ph=$_GET["ph"];

$check_uname="select * from tbl_register where ph='$ph'";
$run=mysql_query($check_uname);
if(mysql_num_rows($run)>0)
{
echo "Number $ph is already exist";
}
else
{
$exe=mysql_query("insert into tbl_register values(null,'$us','$dr','$st','$ar','$ci','$ph','')") or die(mysql_error());

if($exe)
{
   echo "Register Successfully";
}
else
{
  echo "Register Failed Please Try Again";	
}
}
?>
