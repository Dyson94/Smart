<?php

require("conn.php");
$ph=$_GET["ph"];

$exe=mysql_query("select * from tbl_officialbin where ph='$ph'") or die(mysql_error());
$exe1=mysql_query("select * from tbl_publicbin where ph='$ph'") or die(mysql_error());

while($re=mysql_fetch_array($exe))
{
	echo "Officialbin,".$re['date'].",";
	$a=$re['status'];
	if($a=="1")
	{
		echo "Cleared/";
	}
	else{
		echo "On process/";
	}
}
while($re1=mysql_fetch_array($exe1))
{
	echo "Pubilbin,".$re1['date']."," ;
	$a=$re['status'];
	if($a=="1")
	{
		echo "Cleared/";
	}
	else{
		echo "On process/";
	}
}

?>