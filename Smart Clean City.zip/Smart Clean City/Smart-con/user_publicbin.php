<?php
require("conn.php");

$us=$_GET["un"];
$la=$_GET["la"];
$lo=$_GET["lo"];
$ar=$_GET["ar"];
$ci=$_GET["ci"];


$exe=mysql_query("update tbl_publicbin set name='$us',status='1' where status='0'") or die(mysql_error());

if($exe)
{
   echo "Thanks for your request";
}
else
{
  echo "Your request Failed Please Try Again";	
}

?>