<?php
require("conn.php");

$ct = $_REQUEST['id'];

$SQL = "DELETE FROM tbl_employee WHERE empid = '$ct'";
mysql_query($SQL);

echo "<script>location.href = 'view_emp.php'</script>";
?>