<aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu">                
                  <li class="active">
                      <a class="" href="home.php">
                          <i class="icon_house_alt"></i>
                          <span>Home</span>
                      </a>
                  </li>
				  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_desktop"></i>
                          <span>Request Map</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="homebin.php">Home Bin</a></li>                          
                          <li><a class="" href="publicbin.php">Public Bin</a></li>
                      </ul>
                  </li>       
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_desktop"></i>
                          <span>Request</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="homebinreq.php">Home Bin</a></li>                          
                          <li><a class="" href="publicbinreq.php">Public Bin</a></li>
                      </ul>
                  </li>       
                  <li>                     
                      <a class="" href="addemp.php">
                          <i class="icon_document_alt"></i>
                          <span>Add Employee</span>    
                      </a>
                                         
                  </li>
				  
				  <li>                     
                      <a class="" href="schedule.php">
                          <i class="icon_document_alt"></i>
                          <span>Schedule</span>    
                      </a>                 
                  </li>
				  
				  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_desktop"></i>
                          <span>Feed & Com</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="feedback.php">Feedback</a></li>                          
                          <li><a class="" href="comp.php">Complaints</a></li>
                      </ul>
                  </li>       
                             
                  <li class="sub-menu">
                      <a href="javascript:;" class="">
                          <i class="icon_table"></i>
                          <span>Tables</span>
                          <span class="menu-arrow arrow_carrot-right"></span>
                      </a>
                      <ul class="sub">
                          <li><a class="" href="view_emp.php">Employee</a></li>
						  <li><a class="" href="view_user.php">Users</a></li>
					  </ul>
                  </li>
                                    
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      